package com.example.decimals

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
